module.exports = {
    testEnvironment:'node'
}